import sys
import pandas as pd
from Cluster_Utils import *
import os


def get_sum(directory, num_iterations, seq_path):
		#ADD CSV FILE AND FASTA FILE
    c_sum_df = pd.DataFrame(columns = ["Cluster ID", "Cluster Density", "Cluster Abundance"])
                
                #create file of all the rep centroid names
    ids = ""
    densities = {}
    abunds = {}
                
    for i in range(0, num_iterations):                       
        sum_file = directory + "/Iteration_" + str(i) + "/Cluster_Summary.txt"
#        print(sum_file)
        sum_text = pd.read_table(sum_file)
        for index, row in sum_text.iterrows():
            centroid = row["Centroid"]
            densities[centroid] = row["Density"]
            ids = ids + centroid + "\n"
            df_row = {"Cluster ID": centroid, "Cluster Density" : densities[centroid]}
  #          print(df_row)
            c_sum_df = c_sum_df.append(df_row, ignore_index = True)

        with open((directory + '/cluster_it_seq_sum.txt'), 'w') as f:
            f.write(ids)
        f.close()
                

	    #create fasta file
        centroid_sum = Extract_Sequences(seq_path, directory + '/cluster_it_seq_sum.txt', 1, [directory + 'centroid_summary.fna'])
        
                #modify headers of fasta sumary                
        new_file = ''
        with open((directory + 'centroid_summary.fna'), 'r') as fasta_f:                  
            all_lines = fasta_f.read()
            lines = all_lines.split(">") 
            for i in range(1, len(lines)):
                new_row = ''
                line_split = lines[i].split("\n")
                centroid = line_split[0]
                seq_arr = line_split[1:]
                seq = ""
                for j in range(len(seq_arr)):                        
                    seq = seq + seq_arr[j] + "\n"
                if (centroid in densities.keys()):
                        new_row = ">" + centroid + ";density=" + str(densities[centroid]) + "\n" + seq
                else:
                    new_row = lines[i]
                new_file = new_file + new_row  
                         
            with open((directory + '/Fasta_Summary.fna'), 'w') as new_f:
                        new_f.write(new_file)
            new_f.close()

            os.remove(directory + 'centroid_summary.fna')
            os.remove(directory + '/cluster_it_seq_sum.txt')
            c_sum_df.to_csv(directory + '/centroid_sum.csv', sep = '\t')
get_sum("/fs/cbcb-scratch/imittra/long-read-data/MeanSCRAPT/output_10p_80", 50, "/fs/cbcb-scratch/imittra/long-read-data/sampled_data_10p.fasta")

