from Bio import SeqIO
import sys
import math
import argparse as ap
import matplotlib.pyplot as plt
import subprocess
from os import popen, listdir, remove, mkdir 
from os.path import isfile, split, realpath, isdir,dirname
import numpy as np 
import pandas as pd
import random
import time
import sys
from typing import Tuple
import multiprocessing
from shutil import rmtree

def DE_DUPLICATE_SEQUENCES(filepath, out_path)->bool:
	#counts = out_path+"Counts.txt"
	out = out_path+"deduplicated.seqs.fastq"
	command = "seqkit rmdup -s "+filepath+" > "+out
	subprocess.Popen(command,shell=True).wait()
	if isfile(out):
		return True
	return False

def SAMPLE(filepath, frac_seq, output)->bool:
	head, tail = split(filepath)
	command = 'seqkit sample -p '+str(frac_seq)+' -s ' + str(random.randint(0,100)) + ' ' +filepath +' > '+ output + '/Sample.fasta'
	subprocess.Popen(command,shell=True).wait()
	if isfile(output + '/Sample.fasta'):
		return True
	return False

def WRITE_COUNTS_DICT(filepath):
	head, tail = split(filepath)
	lines = open(filepath).readlines()
	d = {}
	for l in lines:
		a = l.split('\t')
		counts = a[0]
		seq_ids = a[1].split(', ')
		d[seq_ids[0]] = {'Counts':counts}#, 'Dup_List':list(seq_ids[1:])}

	f = open(head+'/Counts.dict','w')
	f.write(str(d))
	f.close()
	#remove(filepath)

def build_kmers(func_input):
    id_name, sequence, qual_scores, ksize, threshold, kept_id_filepath = func_input
    kept_kmers = dict()
    n_kmers = len(sequence) - ksize + 1
    removed_kmer_count = 0
    all_qual_scores = []
    array_kept_ids = []
    sum_score = 0
    for i in range(n_kmers):
        #get kmer
        kmer = sequence[i:i + ksize]
        #get array of quality scores for kmer
        kmer_q_score = qual_scores[i:i + ksize]
        #calculate score
        score = calc_score(kmer_q_score)
        #include if score above threshold

        if score != 0:
            sum_score = sum_score + math.log(score)
        else:
            sum_score = sum_score

    avg_score = sum_score / len(sequence)
    if sum_score >= float(threshold):
        with open(kept_id_filepath, "a") as myfile:
            myfile.write(id_name)
            myfile.write("\n")


#score is log of sum of scores rounded to integer
def calc_score(qual_scores):
    sum_score = 0
    #should be log of probability of quality scores
    for i in range(len(qual_scores)):
        sum_score = sum_score + math.log(qual_scores[i])
    return sum_score



#when I add in main scrapt I need to set ksize and add param for threshold
def FILTER_SEQS(seq_path, num_threads, threshold, ksize, directory):
     pool = multiprocessing.Pool(int(num_threads))
     
     command = "seqkit seq -M 2000 " + seq_path + " > " + "filtered_seqs_pre.fastq"
     subprocess.Popen(command, shell=True).wait()
     #dictionary of each sequence's removed counts and total counts
     count_info_arr = []
        #dictionary of all quality scores
     qual_score_arr = []


     func_input = []

        #array of sequences with quality strings
     records = SeqIO.parse("filtered_seqs_pre.fastq","fastq")
     
   
     kept_id_filepath = directory + "Kept_IDS.txt"
     for record in records:
         id_name = record.id
         seq = record.seq
         qual = record.letter_annotations["phred_quality"]
         ksize = ksize
         cut_off = threshold
           #also have to pass in dictionaries that will be changed
         info = (id_name, seq, qual, ksize, cut_off, kept_id_filepath)
         func_input.append(info)
        # print(func_input)

     result = pool.map(build_kmers, func_input)
     pool.close()
     pool.join()
     print("Pools closed")

     out = directory + "filtered_seqs.fastq"
     command = "seqkit grep --pattern-file " + kept_id_filepath + " " + seq_path + " > " + out

     subprocess.Popen(command, shell=True).wait()

     command = "seqkit fq2fa " + out + " -o " + directory + "filtered_seqs.fasta"
     subprocess.Popen(command, shell=True).wait()

     if isfile(out):
         return True
   
     return False


def generate_kmers(prefix, length, nucleotides):
    if length == 0:
        return [prefix]
    else:
        result = []
        for nucleotide in nucleotides:
            result.extend(generate_kmers(prefix + nucleotide, length - 1, nucleotides))
        return result


def make_seq_hash(info):
    id_name, sequence, k, seqs_to_add = info
 
    ht = [0] * len(seqs_to_add)

    for i in range(len(sequence) - k + 1):
        kmer = sequence[i:i + k]
        ind = seqs_to_add.index(kmer)
        ht[ind] = ht[ind] + 1
        

    non_zero_counts = {}
    for i in range (len(ht)):
        if ht[i] != 0:
            non_zero_counts[i] = ht[i]
    ret_arr = []
    ret_arr.append(id_name)
    ret_arr.append(non_zero_counts)
    
    return ret_arr

def MAKE_KMER_HASH(seq_path, ksize, thread_count):
    pool = multiprocessing.Pool(thread_count)
        
    func_input = []

        
    records = SeqIO.parse(seq_path,"fastq")
        
    seqs_to_add = generate_kmers('',ksize, 'ACGT')
    for record in records:
        id_name = record.id
        seq = record.seq
        ksize = ksize
        info = (id_name, seq, ksize, seqs_to_add)
        
        func_input.append(info)
    result = pool.map(make_seq_hash, func_input)
    pool.close()
    pool.join()
    print("Pools closed")
    result = np.array(result)
    
    return result

def FIND_REP_CENTER(func_input):
    
    kmer_dict, ksize, order = func_input
    #get artificial seq

    summed_counts = [0]* (4**ksize)

    for row in kmer_dict:
        seq, counts = row
        for key in counts:
            summed_counts[key] = summed_counts[key] + counts[key]

    avg_counts = [value / len(kmer_dict) for value in summed_counts]
    #print(avg_counts)


#get closest real seq
    smallest_dist = math.inf
    closest_seq = ""
    for row in kmer_dict:
        seq, counts = row
        curr_dist = 0
        j = 0
        while ((curr_dist <= smallest_dist) and (j < len(avg_counts))):
          #  print(seq, curr_dist, smallest_dist)
            if j in counts:
                curr_dist = curr_dist + (avg_counts[j] - counts[j])**2
            if j not in counts:
                curr_dist = curr_dist + (avg_counts[j])**2
            j = j + 1
        
            if ((curr_dist < smallest_dist) and (j == len(avg_counts) - 1)):
               smallest_dist = curr_dist
               closest_seq = seq
              # print("in method: " + seq)
        
    ret = [order,closest_seq]
    #print(ret)
    return ret






def Pick_New_Alpha(curr_counts, prev_counts, prev_alpha, delta = 0.008)->float:
        if (curr_counts < prev_counts):
                return prev_alpha + (1-(curr_counts/prev_counts))*delta
        return prev_alpha

def Parse_DNACLUST_output(dnaclust_op)->Tuple[pd.DataFrame, list, list]:
        lines = open(dnaclust_op,'r').readlines()
        singletons = []
        nonsingletons = []
        cluster_id = 0
        out_list = []
        for l in lines:
                reads = list(set(l.rstrip().split()))
               # print(reads)
                centroid = reads[0]
                density = len(reads)
                
                
                d = {'Cluster_Id':cluster_id, 'Centroid':centroid,'Density':density}
                cluster_id += 1
                if density == 1:
                        singletons += reads
                elif density > 1:
                        nonsingletons += reads
                out_list.append(d)
        df = pd.DataFrame(out_list)
        return df, singletons, nonsingletons

def Cluster_Sequences(sampled_seq_path, dist_cutoff, out_path, num_threads)->Tuple[str, pd.DataFrame]:
        head, tail = split(dirname(realpath(__file__)))
        prog_path = head+'/dnaclust/bin/dnaclust -i '
        dnaclust_call = prog_path + (sampled_seq_path) + ' -s ' + str(dist_cutoff) + ' -t '+num_threads+' > ' + out_path + '/cluster_step'
        start_time = time.time()
        subprocess.call(dnaclust_call, shell=True)
        clust_summary, singletons, nonsingletons = Parse_DNACLUST_output(out_path+'/cluster_step')
        result = " %s minutes " % str(round((time.time() - start_time)/60, 2))
        return result, clust_summary

def Split_Sequences(unclustered_seq_path, split_size, out_dir):
        mkdir(out_dir)
        command = "seqkit split -j 16 "+ unclustered_seq_path +" -s " +str(split_size)+ " -O "+out_dir
        subprocess.Popen(command,shell=True).wait()

def Job(cmd):
    if (cmd == "TERMINATE"):
        return None
    else:
        subprocess.call(cmd, shell=True) 
        return True

def Bait_Sequences_Split_Merge(center_list, unclustered_seq_dir, unclustered_seq_path, dist_cutoff, fnames, num_threads, dna_clust_out_dir):
        start_time = time.time()
        f = open(fnames[0],'w')
        lines = [c+'\n' for c in center_list]
        f.writelines(lines)
        f.close()

        flag = Extract_Sequences(unclustered_seq_path, fnames[0], 1, fnames[1:])
        mkdir(dna_clust_out_dir)

        bait_samples = listdir(unclustered_seq_dir)
        head, tail = split(dirname(realpath(__file__)))
        prog_path = head+'/dnaclust/bin/dnaclust -i '
        
        commands = []
        #print(unclustered_seq_dir)
        

        for i in range(len(bait_samples)):
       #     print(bait_samples[i])
            if bait_samples[i].endswith(".fasta"):
                seq_path = unclustered_seq_dir + bait_samples[i]
                dna_clust_op_path = dna_clust_out_dir+'dnaclust.'+str(i)+'.out'
                dnaclust_bait = prog_path + seq_path + ' -s ' + dist_cutoff + ' -p ' + fnames[1] + ' -r  -t '+ num_threads + ' > ' + dna_clust_op_path
                print(dnaclust_bait)
                commands.append(dnaclust_bait)
        commands.append("TERMINATE")

        pool = multiprocessing.Pool(int(num_threads))
        result = pool.map(func=Job, iterable=commands)
        pool.close()
        pool.join()
        
        d = {}
        for i in listdir(dna_clust_out_dir):
                lines = open(dna_clust_out_dir + i,'r').readlines()
                for l in lines:
                        l = l.rstrip().split()
                        if len(l) == 1:
                                try:
                                        d[l[0]] = d[l[0]] + []
                                except KeyError:
                                        d[l[0]] = []
                        else:
                                try:
                                        d[l[0]] = d[l[0]] + l[1:]
                                except KeyError:
                                        d[l[0]] = l[1:]
        o = open(fnames[2],'w')
        for k in d:
                app = " ".join(d[k])
                o.write(k + " " + app+"\n")
        o.close()

        clust_summary, singletons, nonsingletons = Parse_DNACLUST_output(fnames[2])
        result = " %s minutes " % str(round((time.time() - start_time)/60, 2))
        rmtree(dna_clust_out_dir)

        return result, clust_summary, singletons, nonsingletons

def Bait_Sequences(center_list, unclustered_seq_path, dist_cutoff, fnames, num_threads)->Tuple[str, pd.DataFrame, list, list]:
        ###fnames[0]: pattern name, fnames[1]: center_names fnames[2]: unclust fnames[3]: bait_op
        start_time = time.time()
        f = open(fnames[0],'w')
        lines = [c+'\n' for c in center_list]
        f.writelines(lines)
        f.close()
        flag = Extract_Sequences(unclustered_seq_path, fnames[0], 0, fnames[1:])
        if(flag):
                head, tail = split(dirname(realpath(__file__)))
                prog_path = head+'/dnaclust/bin/dnaclust -i '
                dnaclust_bait = prog_path + fnames[2] + ' -s ' + dist_cutoff + ' -p ' + fnames[1] + ' -r  -t '+ num_threads + ' > ' + fnames[3]
                subprocess.call(dnaclust_bait, shell=True)
                clust_summary, singletons, nonsingletons = Parse_DNACLUST_output(fnames[3])
                result = " %s minutes " % str(round((time.time() - start_time)/60, 2))
                remove(fnames[0])
                remove(fnames[1])
                remove(fnames[2])

                return result, clust_summary, singletons, nonsingletons
        else:
                print('Failed to extract sequences... check commands')
                sys.exit(1)

def Extract_Sequences(seq_file, pattern_file, filter_type, names)->bool:
        #both = 0, found = 1, not_found = 2
        command_extract_found = "seqkit grep --pattern-file "+pattern_file +" "+seq_file
        command_extract_notfound =  "seqkit grep -v --pattern-file "+pattern_file +" "+seq_file

        if filter_type == 0:
                if len(names) == 1:
                        return False
                subprocess.call(command_extract_found + " > "+names[0],shell=True)
                subprocess.call(command_extract_notfound+" > "+names[1],shell=True)
                return True
        elif filter_type == 1:
                if len(names) == 0:
                        return False
                subprocess.call(command_extract_found + " > "+names[0],shell=True)
                return True

        elif filter_type == 2:
                if len(names) == 0:
                        return False
                subprocess.call(command_extract_notfound+" > "+names[0],shell=True)
                return True


def Get_Summary(df_clust_bait, df_clust_modeshift, min_cluster_size)->dict:
        d = {}
        d['Number of clusters(Baiting on dnaclust centers)'] =  len(df_clust_bait.loc[df_clust_bait['Density'] > 1])
        d['Clustered sequences(Baiting on dnaclust centers)'] = df_clust_bait.loc[df_clust_bait['Density'] > 1,'Density'].sum()
        d['Densest cluster(Baiting on dnaclust centers)'] = df_clust_bait['Density'].max()
        d['Average number of sequences per cluster(Baiting on dnaclust centers)'] = df_clust_bait.loc[df_clust_bait['Density'] > 1, 'Density'].mean()
        d['Median number of sequences per cluster(Baiting on dnaclust centers)'] = df_clust_bait.loc[df_clust_bait['Density'] > 1, 'Density'].median()
        d['Num Clusters Above Min Cluster Size(Baiting on dnaclust centers)'] = len(df_clust_bait.loc[df_clust_bait['Density'] >= min_cluster_size])
      
        if len(df_clust_modeshift) > 0:
                d['Densest cluster(After shifting the centers)'] = df_clust_modeshift['Density'].max()
                d['Average number of sequences per cluster(After shifting the centers)']  = df_clust_modeshift.loc[df_clust_modeshift['Density']>1, 'Density'].mean()
                d['Number of clusters(After shifting the centers)'] = len(df_clust_modeshift.loc[df_clust_modeshift['Density'] > 1])
                d['Clustered sequences(After shifting the centers)'] = df_clust_modeshift.loc[df_clust_modeshift['Density'] > 1,'Density'].sum()
                d['Median number of sequences per cluster(After shifting the centers)']  = df_clust_modeshift.loc[df_clust_modeshift['Density']>1, 'Density'].median()
                d['Num Clusters Above Min Cluster Size(After shifting the centers)'] = len(df_clust_modeshift.loc[df_clust_modeshift['Density'] >= min_cluster_size])
      
        return d

def SCRAPT_Iteration(unclustered_seqs, unclustered_seq_count, sampling_rate, out_path, iter_id, min_cluster_size, d_cutoff, kmer_dict, num_threads, meanshift_flag)->Tuple[dict, list]:
       # print(kmer_dict)
        #####SAMPLING
        print("sampled")
        iteration_time = time.time()
        mkdir(out_path)
        f = SAMPLE(unclustered_seqs, sampling_rate, out_path)
        if f == False:
                print("Failed to sample sequences. Check")
                sys.exit(0)
        sampled_seq = out_path+'/Sample.fasta'
        
        #####CLUSTERING
        print("clustered")
        cluster_time, cluster_summary = Cluster_Sequences(sampled_seq, str(d_cutoff), out_path, num_threads)
        
        ######Split_Fasta_Files
        split_size = min(int(unclustered_seq_count/int(num_threads)), 1000000)
        Split_Sequences(unclustered_seqs, split_size, out_path + '/Split_Seqs/')

        
        #####BAITING
        try:
                print("baiting")
                
                bait_centroids = cluster_summary.loc[((cluster_summary['Density'] > 1)), 'Centroid'].tolist()
     #           print("second try", bait_centroids)
        except KeyError:
                
                return {}, unclustered_seqs

        op_filenames = [out_path+'/bait_centroids.txt', out_path+'/bait_centroids.fasta', out_path+'/dnaclust_bait']
        (bait_time, 
         bait_summary, 
         bait_singletons, 
         bait_nonsingletons) = Bait_Sequences_Split_Merge(bait_centroids, out_path+'/Split_Seqs/', unclustered_seqs, str(d_cutoff), op_filenames, num_threads, out_path+'/Bait/')
        
     
        #####MEAN SHIFTING
        if meanshift_flag == True:
                try:
                        print("mean centers")
                        mean_centroids = []
                        with open( out_path+'/dnaclust_bait', 'r') as file:
                            count = 0
                            func_input = []
                            for line in file:
                                seqs = line.strip().split()
                                indices = np.isin(kmer_dict[:,0], seqs)
                                part_kmers = kmer_dict[indices]
                                #5 is passed in as kmer size
                                to_add = [part_kmers, 5, count]
                                func_input.append(to_add)
                                count = count + 1
              
                            pool = multiprocessing.Pool(int(num_threads))
                            result = pool.map(FIND_REP_CENTER, func_input)
                            pool.close()
                            pool.join()
      #                      print(result)
                            #print(result)
     #                       result = np.argsort(result[:, 0]).tolist()
                            result = sorted(result, key=lambda x: x[0])
                            result = [row[1:] for row in result]
                            result =  [element for row in result for element in row]
                            
                            mean_centroids = result
                            print(mean_centroids)
                            #mean_centroids.append(centroid)
                        op_filenames = [out_path+'/bait_mean.txt', out_path+'/bait_mean.fasta', out_path+'/dnaclust_mean_bait']
                        (mean_shift_time, 
                         mean_shift_summary, 
                         mean_shift_singletons, 
                         mean_shift_nonsingletons) = Bait_Sequences_Split_Merge(mean_centroids, out_path+'/Split_Seqs/',unclustered_seqs, str(d_cutoff), op_filenames, num_threads, out_path+'/Bait_Mean/')
                        mean_shift_summary.to_csv(out_path+'/Cluster_Summary.txt', sep = '\t')
                        clustered_seqs_list = mean_shift_nonsingletons
                except KeyError:
                        mean_shift_summary = []
                        mean_shift_singletons = []
                        clustered_seqs_list = bait_nonsingletons
                        bait_summary.to_csv(out_path+'/Cluster_Summary.txt', sep = '\t')
                        mean_shift_time = 0

        else:
                mean_shift_summary = []
                mean_shift_singletons = []
                clustered_seqs_list = bait_nonsingletons
                bait_summary.to_csv(out_path+'/Cluster_Summary.txt', sep = '\t')
                mean_shift_time = 0

        #####CREATE UNCLUSTERED SEQUENCES
        print("unclusted seqs")
        fp = open(out_path+'/unclustered_seqs','w')
        lines = [c + '\n' for c in clustered_seqs_list]
        fp.writelines(lines)
        fp.close()
        unclust_extract = Extract_Sequences(unclustered_seqs, out_path+'/unclustered_seqs', 2, [out_path+'/unclustered_seqs_'+str(iter_id)+'.fasta'])
        if(unclust_extract == False):
                print('Failed to extract unclustered sequences')
                sys.exit(0)   
        iter_bm = " %s minutes " % str(round((time.time() - iteration_time)/60, 2))
        remove(sampled_seq)
        if iter_id > 1:
                remove(unclustered_seqs)

        ######SUMMARIZE CLUSTERS
        print("summarize clusters")
        rmtree(out_path + '/Split_Seqs/')
        unclustered_seqs = out_path+'/unclustered_seqs_'+str(iter_id)+'.fasta'
        if len(bait_summary) == 0:
                return {}, unclustered_seqs
                
        d = Get_Summary(bait_summary, mean_shift_summary, min_cluster_size)
        d['Sampling Rate'] = sampling_rate
        d['Cluster Singletons'] = len(cluster_summary[cluster_summary['Density'] == 1])
        d['Singletons(Baiting on dnaclust centers)'] = len(bait_singletons)
        d['Singletons(After shifting the centers)'] = len(mean_shift_singletons)
        d['Time(Cluster)'] = cluster_time
        d['Time(Bait)'] = bait_time
        d['Time(Mode shift)'] =  mean_shift_time
        d['Time(Total)'] = iter_bm
        d['Iteration'] = iter_id

        return d, unclustered_seqs
